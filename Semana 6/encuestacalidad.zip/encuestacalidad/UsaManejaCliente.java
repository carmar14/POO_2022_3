package encuestacalidad;
public class UsaManejaCliente {
    public static void main(String[] args){
        ManejaCliente mc;
        mc = new ManejaCliente();
        mc.gestionar();
    }
}
