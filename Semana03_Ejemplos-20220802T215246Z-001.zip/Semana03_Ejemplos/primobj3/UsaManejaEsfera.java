package primobj3;
public class UsaManejaEsfera {
    public static void main(String args[]){
        ManejaEsfera me;
        me = new ManejaEsfera();
        me.gestionar();
    }
}
