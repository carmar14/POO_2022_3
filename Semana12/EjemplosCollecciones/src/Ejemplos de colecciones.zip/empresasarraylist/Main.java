package empresasarraylist;
public class Main {
    public static void main(String[] args){
        GestionEmpresas ge = new GestionEmpresas();
        ge.gestionar();
    }
}
