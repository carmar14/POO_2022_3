package paisesycapitalesarraylist;
public class Main {
    public static void main(String[] args){
        GestionPaisesYCapitales gpyc = new GestionPaisesYCapitales();
        gpyc.gestionar();
    }
}
