package numeros;
public class Main {
    public static void main(String[] args){
        GestionNumeros gn = new GestionNumeros();
        gn.gestionar();
    }
}
