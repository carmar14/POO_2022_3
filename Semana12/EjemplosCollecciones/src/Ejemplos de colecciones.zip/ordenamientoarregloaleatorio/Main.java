package ordenamientoarregloaleatorio;
public class Main {
    public static void main(String[] args){
        GestionNumerosAleatorios gna = new GestionNumerosAleatorios();
        gna.gestionar();
    }
}
