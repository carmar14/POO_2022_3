package ambito;
import javax.swing.JOptionPane;

/**
 *
 * @author Juan Manuel
 */
public class EjemploAmbito3 {

    public static void main(String[] args){
        int i;
        for(i=0;i<3;i++){
            JOptionPane.showMessageDialog(null, "Debo estudiar Java");
        }
        JOptionPane.showMessageDialog(null, "El valor de i es "+i);
    }

}
