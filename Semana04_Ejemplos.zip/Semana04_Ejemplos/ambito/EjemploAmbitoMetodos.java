package ambito;
import javax.swing.JOptionPane;

/**
 *
 * @author Juan Manuel
 */
public class EjemploAmbitoMetodos {
    public static void main(String[] args){
        int x;
        EjemploAmbitoMetodos eam;
        eam = new EjemploAmbitoMetodos();
        x = 89;
        eam.mostrarMensaje();
        JOptionPane.showMessageDialog(null,"x="+x);
    }

    void mostrarMensaje(){
        JOptionPane.showMessageDialog(null,"x="+x);
    }
}
