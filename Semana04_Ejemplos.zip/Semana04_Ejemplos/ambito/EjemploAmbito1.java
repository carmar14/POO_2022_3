package ambito;
import javax.swing.JOptionPane;
public class EjemploAmbito1 {
    public static void main(String[] args){
        int x = 12;
        {
            int q = 96;
            JOptionPane.showMessageDialog(null,
                    "x="+x+", q="+q);
        }
        JOptionPane.showMessageDialog(null,
                "x="+x+", q="+q);
    }
}
