package ambito;
import javax.swing.JOptionPane;
public class EjemploAmbito {
    public static void main(String[] args){
        x = 30;
        JOptionPane.showMessageDialog(null,
                "El valor de x es "+x);
        int x;
    }
}
