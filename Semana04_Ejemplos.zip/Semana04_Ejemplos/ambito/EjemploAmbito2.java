package ambito;
import javax.swing.JOptionPane;

/**
 *
 * @author Juan Manuel
 */
public class EjemploAmbito2 {

    public static void main(String[] args){
        for(int i=0;i<3;i++){
            JOptionPane.showMessageDialog(null, "Debo estudiar Java");
        }
        JOptionPane.showMessageDialog(null, "El valor de i es "+i);
    }

}
