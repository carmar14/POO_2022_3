package primerosobjetos;
import javax.swing.JOptionPane;
public class Vehiculo {
    double recorrido_diario=30;
    double recorrido_galon=45;
    void mostrarConsumo(){
        double consumo_diario =
                recorrido_diario/recorrido_galon;
        JOptionPane.showMessageDialog(null,
                "El consumo diario del vehículo"+
                " es: "+consumo_diario+" galones");
    }
}
