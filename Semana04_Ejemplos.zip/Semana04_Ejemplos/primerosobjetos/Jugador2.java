package primerosobjetos;
import javax.swing.JOptionPane;
public class Jugador2 {
    String nickname;
    int puntaje;
    Jugador2(String nick){
        nickname = nick;
        puntaje  = 0;
        JOptionPane.showMessageDialog(null,
                "Se ha creado el jugador "+
                nickname);
    }
    void asignarPuntaje(int p){
        puntaje = p;
    }
    public static void main(String[] args){
        String sobrenombre;
        sobrenombre = JOptionPane.showInputDialog(
                "Digite el nombre de su avatar");
        Jugador2 j;
        j = new Jugador2(sobrenombre);
        j.asignarPuntaje(100);
    }
}
