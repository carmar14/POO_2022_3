package primerosobjetos;
public class Mascota {
    String nombre;
    String especie;
    void asignarNombre(String n){
        nombre = n;
    }
    void asignarEspecie(String e){
        especie = e;
    }
}

