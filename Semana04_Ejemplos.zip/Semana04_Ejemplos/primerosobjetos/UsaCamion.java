package primerosobjetos;
import javax.swing.JOptionPane;
public class UsaCamion {
    public static void main(String[] args){
        int kilom;
        Camion c;
        c = new Camion();
        kilom = c.obtenerKilometraje();
        JOptionPane.showMessageDialog(null,
                "El kilometraje del camión es "
                +kilom);
    }
}

