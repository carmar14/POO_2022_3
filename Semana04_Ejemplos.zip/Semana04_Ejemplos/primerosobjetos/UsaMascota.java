package primerosobjetos;
import javax.swing.JOptionPane;
public class UsaMascota {
    public static void main(String[] args){
        Mascota m = new Mascota();
        String nom_masc = JOptionPane.showInputDialog(
                "Digita el nombre de la mascota"
                );
        m.asignarNombre(nom_masc);
        String esp_masc = JOptionPane.showInputDialog(
                "Digita el nombre de la especie"
                );
        m.asignarNombre(esp_masc);
    }
}


