package primerosobjetos;
import javax.swing.JOptionPane;
public class Despliegue {
    void imprimirMensaje(String cadena){
        JOptionPane.showMessageDialog(null,
            "El valor de la cadena es: "+cadena);
    }
    void imprimirMensaje(int entero){
        JOptionPane.showMessageDialog(null,
            "El valor del entero es: "+entero);
    }
    void imprimirMensaje(double real){
        JOptionPane.showMessageDialog(null,
            "El valor del real es: "+real);
    }
    public static void main(String[] args){
        Despliegue d = new Despliegue();
        d.imprimirMensaje(200);
        d.imprimirMensaje("Viva Colombia!");
        d.imprimirMensaje(3.1492);
    }
}
