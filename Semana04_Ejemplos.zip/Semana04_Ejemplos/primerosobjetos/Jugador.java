package primerosobjetos;
import javax.swing.JOptionPane;
public class Jugador {
    String nickname;
    int puntaje;
    Jugador(){
        nickname = "";
        puntaje  = 0;
        JOptionPane.showMessageDialog(null,
                "Se ha creado un jugador ");
    }
    public static void main(String[] args){
        Jugador j;
        j = new Jugador();
    }
}

