package primerosobjetos;
public class Camion {
    int kilometraje=1200;
    int obtenerKilometraje(){
        return kilometraje;
    }
}

