package primerosobjetos;
public class UsaPractica {
    public static void main(String[] args){
        Practica p;
        p = new Practica();
        p.mostrarMensajes();
    }
}

