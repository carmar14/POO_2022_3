package primerosobjetos;
import javax.swing.JOptionPane;
public class Persona {
    String nombre="Carolina Corredor";
    int edad=19;
    double estatura=1.62, peso=56;
    void mostrarInformacion(){
        JOptionPane.showMessageDialog(null,
                nombre+" tiene "+edad+ "años"+
                ", mide "+estatura+" metros"+
                "y pesa "+peso+" kg");
    }
    void mostrarIMC(){
        double imc = peso/(estatura*estatura);
        JOptionPane.showMessageDialog(null,
                "El IMC de "+nombre+" es "+imc);
    }
}
