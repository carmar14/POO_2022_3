package primerosobjetos;
import javax.swing.JOptionPane;
public class Practica {
    void mostrarBienvenida(){
        JOptionPane.showMessageDialog(null,
                "Bienvenido a este programa");
    }
    void mostrarMensajeSuperacion(){
        JOptionPane.showMessageDialog(null,
            "Nadie es libre si no es dueño de sí mismo"
            + " -Epicteto");
    }
    void mostrarMensajes(){
        this.mostrarBienvenida();
        this.mostrarMensajeSuperacion();
    }
}



