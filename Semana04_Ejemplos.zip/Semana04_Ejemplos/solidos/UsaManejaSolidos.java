package solidos;
public class UsaManejaSolidos {
    public static void main(String args[]){
        ManejaSolidos ms = new ManejaSolidos();
        ms.gestionar();
    }
}
