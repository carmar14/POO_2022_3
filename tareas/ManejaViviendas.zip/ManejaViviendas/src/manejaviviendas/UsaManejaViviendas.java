
package ManejaViviendas;


public class UsaManejaViviendas {
        public static void main(String[] args) {
        ManejaViviendas mv = new ManejaViviendas();
        mv.gestionar();
        
    }
}
